#include "mergetars.h"

int sample() {
  printf("go away make");
  return 0;
}
