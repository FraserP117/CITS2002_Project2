#include "mergetars.h"

char **tarfiles = NULL;

int sample() {
  printf("go away make");
  return 0;
}
