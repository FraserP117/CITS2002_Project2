#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdarg.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/param.h>

// int MAXPATHLEN has a value of 1024 (bytes).
extern int NUM_TARFILES;
extern int MAX_SUB_FILES;
extern char **tarfiles; // pointer to an array of strings

// tarfile stuff:
extern char **tarfiles; // pointer to an array of strings
extern int ntarfiles;

// the tarfile parser:
extern void parse_tarfiles(char[]);

// the checker functions:
extern bool is_tarfile_content_duplicate(char[]);
extern bool check_tarfile_size_duplicate(char[]);
extern bool check_tarfile_date_duplicate(char[]);

// // initial structure contents:
// extern struct all_tarfiles;
// extern struct one_tarfile;
// extern struct subfile;
//
// extern char file_path[MAXPATHLEN];
// extern int file_size;
// extern char mod_time[2];
//
// // final structure contents:
// // add to list of questions
// extern struct all_unique_tarfiles;
// extern struct Unique_subfile;
// extern struct Unique_subfile_file_info;
//
// extern char u_file_path[MAXPATHLEN];
// extern int u_file_size;
// extern char u_mod_time[2];
